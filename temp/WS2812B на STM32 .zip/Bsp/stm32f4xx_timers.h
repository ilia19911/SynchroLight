#ifndef __STM32F10X_TIMERS
  #define __STM32F10X_TIMERS

void Timer4_init(void);


#endif

