#ifndef __STM32F4X_DMA
  #define __STM32F4X_DMA

void Clear_DMA(void);
void DMA1_Stream7_Mem_to_TMR4_init(void);

#endif

